Balsamiq Sans is the handwritten font created for the Balsamiq Wireframes and has been in use since version 2.1.

The font contains 942 glyphs in 2 weights with italics/obliques, and includes the basic and extended latin character set, Cyrillic, Basic Symbols and Dingbats, Math and Technical Symbols, and punctuation

To contribute, see [https://github.com/balsamiq/balsamiqsans](https://github.com/balsamiq/balsamiqsans)